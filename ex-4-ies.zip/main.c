/*4. Fac¸a um programa que receba do usuario um arquivo texto e mostre na tela quantas ´
letras sao vogais e quantas s ˜ ao consoantes. 

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 10000

void vogaisecons(char str[], int n){
    int i, c=0, j=0;
    char vogais[] = "aeiouAEIOU";
    
    for(i=0; i<n; i++){
        if (strchr(vogais, str[i]) != NULL) c++;
        if (isalpha(str[i]) && !strchr(vogais, str[i])) j++;
    }
    printf("A quantidade de vogais no arquivo é: %d\n", c);
    printf("A quantidade de consoantes no arquivo é: %d\n", j);
}

int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX];
    int erro, tam;
    
    erro = lerarq("arq.txt", ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    vogaisecons(ch, tam);
   
    return 0;
}
